﻿# Readme


---

项目语言python3.5
依赖库：sklearn, pandas, numpy, IPython.display.




