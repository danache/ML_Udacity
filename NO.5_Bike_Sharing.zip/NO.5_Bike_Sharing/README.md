# Kaggle Bike Rent Project

> To solve Bike Sharing Demand project , see detail description in https://www.kaggle.com/c/bike-sharing-demand

This project is made to solve Kaggle Bike Rent Project in Kaggle.
I first take data procession to transform feature and remove it.Then I choose random forest model , decision tree model, SVM to fit data.Then I use grid search to find better parameters for random forest.The final results rank top 20% in kaggle.


### Environment
The peojected is written in python3.5。
Librarys：sklearn, pandas, numpy, IPython.display。

### Usage
You can use python compiler to execute bike.py to get result.

### Meta
danache - danache@126.com
